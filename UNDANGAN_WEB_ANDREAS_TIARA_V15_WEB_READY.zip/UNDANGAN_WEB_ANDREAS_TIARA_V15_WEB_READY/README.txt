UNDANGAN ANDREAS & TIARA — V15 (WEB READY)

Tujuan:
- Bisa dibuka di Android / iPhone / iPad / Mac / Windows lewat LINK yang Anda share.
- Tidak perlu terminal/local server.
- Musik & foto jadi asset terpisah (lebih ringan dan stabil daripada 1 file HTML raksasa).

ISI FOLDER:
- index.html
- assets/
  - bgm.mp3
  - bgm_alt.mp3
  - silhouette.jpg
  - prewedding_1.jpg
  - prewedding_2.jpg
  - prewedding_3.jpg

CARA PUBLISH (PILIH SALAH SATU):
1) Netlify (paling gampang):
   - Buka Netlify → Add new site → Deploy manually / Drag & drop
   - Drag folder ini (atau ZIP ini) ke halaman deploy
   - Netlify akan kasih URL, itu yang Anda share ke tamu.

2) GitHub Pages:
   - Buat repo baru → upload isi folder ini
   - Settings → Pages → pilih branch → Save
   - Anda akan dapat URL Pages, share ke tamu.

3) Cloudflare Pages:
   - Create project → upload / connect repo
   - Build: none (static)
   - Deploy → dapat URL, share ke tamu.

CATATAN PENTING (MUSIK):
- Browser (Android/iOS) hampir selalu butuh 1 klik/tap dulu untuk mulai musik.
- Di versi ini, kalau musik belum bisa autoplay, akan muncul banner "Tap untuk menyalakan musik".

UBAH VIDEO YOUTUBE:
- Cari di index.html: iframe id="videoFrame"
- Ganti ID video pada src="https://www.youtube.com/embed/<ID>"

SELESAI.
